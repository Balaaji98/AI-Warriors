Competition Template - Quickstart
================================

This scaffold contains a minimal FastAPI backend and a Vite+React frontend.
It's designed for quick adaptation in time-limited competitions.

Quick run (locally)
-------------------
1. Backend:
   cd backend
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   python init_db.py
   python seed_data.py
   uvicorn app.main:app --reload --port 8000

2. Frontend:
   cd frontend
   npm install
   npm run dev
   Open http://localhost:5173
