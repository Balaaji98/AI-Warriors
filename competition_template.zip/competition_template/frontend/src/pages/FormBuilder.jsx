import React, {useState} from 'react'

export default function FormBuilder(){
  const [form, setForm] = useState({name:'', description:'', qty:1, unit_price:0})

  const submit = async (e) => {
    e.preventDefault()
    await fetch('/api/v1/items', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(form)
    })
    alert('Submitted — refresh dashboard to see data.')
  }

  return (
    <div>
      <h2 className="text-xl mb-4">Create Item</h2>
      <form onSubmit={submit} className="space-y-3 max-w-md">
        <div>
          <label className="block text-sm">Name</label>
          <input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="w-full p-2 rounded bg-gray-800"/>
        </div>
        <div>
          <label className="block text-sm">Description</label>
          <input value={form.description} onChange={e=>setForm({...form,description:e.target.value})} className="w-full p-2 rounded bg-gray-800"/>
        </div>
        <div className="flex gap-2">
          <div className="flex-1">
            <label className="block text-sm">Qty</label>
            <input type="number" value={form.qty} onChange={e=>setForm({...form,qty:parseInt(e.target.value||0)})} className="w-full p-2 rounded bg-gray-800"/>
          </div>
          <div className="flex-1">
            <label className="block text-sm">Unit Price</label>
            <input type="number" value={form.unit_price} onChange={e=>setForm({...form,unit_price:parseFloat(e.target.value||0)})} className="w-full p-2 rounded bg-gray-800"/>
          </div>
        </div>
        <button className="px-4 py-2 bg-indigo-600 rounded">Submit</button>
      </form>
    </div>
  )
}
