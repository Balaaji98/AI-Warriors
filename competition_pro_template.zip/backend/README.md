# Backend

FastAPI backend for competition template.
