#!/usr/bin/env bash
echo "Starting backend and frontend (make sure to run in two terminals or use tmux)"
echo "Backend: cd backend && python -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt && python init_db.py && python seed_data.py && uvicorn app.main:app --reload --port 8000"
echo "Frontend: cd frontend && npm install && npm run dev"
