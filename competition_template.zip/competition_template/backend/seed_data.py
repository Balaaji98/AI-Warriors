from app.db.session import engine, get_session
from app.models import Item
from sqlmodel import Session

samples = [
    {'name': 'Website Design', 'description': 'Corporate web portal UI/UX', 'qty':1, 'unit_price':25000},
    {'name': 'Backend Development', 'description': 'FastAPI-based REST backend', 'qty':1, 'unit_price':30000},
    {'name': 'Support', 'description': '30 days technical support', 'qty':1, 'unit_price':5000},
]

if __name__ == '__main__':
    SQLModel.metadata.create_all(engine)
    with Session(engine) as session:
        for s in samples:
            item = Item(**s)
            session.add(item)
        session.commit()
    print('Seeded sample data')
