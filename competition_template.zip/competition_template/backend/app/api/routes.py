from fastapi import APIRouter, Depends, UploadFile, File, BackgroundTasks, WebSocket
from typing import List
from sqlmodel import select
from app.db.session import get_session, engine
from app.models import Item, SQLModel

router = APIRouter()

# simple health
@router.get('/health')
def health():
    return {'status': 'ok'}

# create DB tables (call during setup)
@router.post('/init-db')
def init_db():
    SQLModel.metadata.create_all(engine)
    return {'ok': True}

@router.post('/items')
def create_item(item: Item, session = Depends(get_session)):
    session.add(item)
    session.commit()
    session.refresh(item)
    return item

@router.get('/items', response_model=List[Item])
def list_items(skip: int = 0, limit: int = 100, session = Depends(get_session)):
    q = select(Item).offset(skip).limit(limit)
    return session.exec(q).all()

@router.post('/upload')
async def upload_file(file: UploadFile = File(...)):
    dest = f'/tmp/{file.filename}'
    with open(dest, 'wb') as f:
        f.write(await file.read())
    return {'filename': file.filename, 'path': dest}
